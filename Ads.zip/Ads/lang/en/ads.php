<?php
return [
    // General editor terms
    'create' => 'Create Ads',
    'display' => 'To display the ad use the code below in your blade',
    'headerad' => 'Header Ad',
	'footerad' => 'Footer Ad',
    'sidebarad' => 'Sidebar Ad',
    'anypage' => 'Any Page Ad',
    'note' => 'Note',
    'script' => 'Script code will only work if you add',
    'toyour' => 'to your .env file',
    'samples' => 'Ads Display Samples',
	 'save' => 'Save Ads',
];
