@extends('layouts.simple')

@section('content')
@push('styles')
article p {
	text-align: justify;
}
main {
	flex: 3;
}
article {
	margin-bottom: 3px;
	padding: 3px 5px;
	border: 1px solid #fff;
	margin-right: 10px;
	text-wrap:pretty;
}
.container { display: flex; justify-content: space-between; max-width: 100%; margin: 0 auto; padding: 10px; flex-wrap: wrap; /* Allows items to wrap on smaller screens */}
article h3 {
  font-family:"Segoe print", Arial, Helvetica, sans-serif;
 font-size:26px;
  padding:0 0 0 0;
  font-weight:bolder;
  -moz-box-shadow:none;  
  -webkit-box-shadow: none;  
  box-shadow:none;  
  display:block;
  min-width:800;
  max-height:172px;
  max-width:800px;  
line-height: 1;
 -webkit-font-smoothing: antialiased;
 -moz-osx-font-smoothing: grayscale;
	margin-right: 10px;font-weight:bold; background-color:#fff;	
}
aside{
	flex: 1;
	background-color: #fff;
	padding: 15px;
margin: 15px;
}
/* Responsive styles */
@media (max-width: 768px) {
	.container {
		flex-direction: column; /* Stacks items vertically on small screens */
	}
	main, aside {
		flex: 1 100%; /* Takes full width */
		margin-right: 0; /* Remove margin on smaller screens */
	}
}
@media (max-width: 480px) {
	.container {
		padding: 10px;
	}
	article {
		padding: 10px;
	}
@endpush
  <div class="container">
	<main> 
		<article> 
    <h1>{{ trans('ads.create') }}</h1>

    @if ($errors->any())
        <div class="custom-alert">
            <ul>
                @foreach ($errors->all() as $error)
                    <li>{{ $error }}</li>
                @endforeach
            </ul>
        </div>
    @endif

    @if (session('success'))
        <div class="alert alert-success">
            {{ session('success') }}
        </div>
    @endif

    <form method="POST" action="{{ route('ads.storeAds') }}">
        @csrf
        <div class="form-group">
            <label for="header_ad"><strong>{{ trans('ads.headerad') }}: </strong>{{ trans('ads.display') }}<pre><code>&#123;&#123;!! getAd('header_ad') !!&#125;&#125;</code></pre></label>
				
				
            <textarea rows="4" cols="5" style="width: 100%; height: 100px;" name="header_ad" class="form-control" id="header_ad">{{ old('header_ad', $ads->header_ad ?? '') }}</textarea>
        </div>
        <div class="form-group">
            <label for="header_ad"><strong>{{ trans('ads.footerad') }}:</strong> {{ trans('ads.display') }}<pre><code>&#123;&#123;!! getAd('footer_ad') !!&#125;&#125;</code></pre></label>
            <textarea rows="4" cols="5" style="width: 100%; height: 100px;" name="footer_ad" class="form-control" id="footer_ad">{{ old('footer_ad', $ads->footer_ad ?? '') }}</textarea>
        </div>
        <div class="form-group">
           <label for="header_ad"><strong>{{ trans('ads.sidebarad') }}:</strong> {{ trans('ads.display') }}<pre><code>&#123;&#123;!! getAd('sidebar_ad') !!&#125;&#125;</code></pre></label>
            <textarea rows="4" cols="5" style="width: 100%; height: 100px;" name="sidebar_ad" class="form-control" id="sidebar_ad">{{ old('sidebar_ad', $ads->sidebar_ad ?? '') }}</textarea>
        </div>
        <div class="form-group">
          <label for="header_ad"><strong>{{ trans('ads.anypage') }}:</strong> {{ trans('ads.display') }}<pre><code>&#123;&#123;!! getAd('show_page_ad_1') !!&#125;&#125;</code></pre></label>
            <textarea rows="4" cols="5" style="width: 100%; height: 100px;" name="show_page_ad_1" class="form-control" id="show_page_ad_1">{{ old('show_page_ad_1', $ads->show_page_ad_1 ?? '') }}</textarea>
        </div>
        <div class="form-group">
          <label for="header_ad"><strong>{{ trans('ads.anypage') }}:</strong> {{ trans('ads.display') }}<pre><code>&#123;&#123;!! getAd('show_page_ad_2') !!&#125;&#125;</code></pre></label>
            <textarea rows="4" cols="5" style="width: 100%; height: 100px;" name="show_page_ad_2" class="form-control" id="show_page_ad_2">{{ old('show_page_ad_2', $ads->show_page_ad_2 ?? '') }}</textarea>
        </div>
        <button type="submit" class="button">{{ trans('ads.save') }}</button>
    </form>
			</article> </main> 
	
		
<aside> 
	 <div class="">
        <div class="aside">
			<div class="card" style="padding:10px;">
			<strong style="color:red;"> {{ trans('ads.note') }}:</strong> {{ trans('ads.script') }} <pre><code>ALLOW_CONTENT_SCRIPTS=true</code></pre>  {{ trans('ads.toyour') }}.
				
				</div>
			<h2 style="font-weight:bold;">{{ trans('ads.samples') }}</h2>

    <h5>{{ trans('ads.headerad') }}</h5>{!! getAd('header_ad') !!}  
	<h5>{{ trans('ads.footerad') }}</h5>{!! getAd('footer_ad') !!}  
	<h5>{{ trans('ads.sidebarad') }}</h5>{!! getAd('sidebar_ad') !!} 
	<h5>{{ trans('ads.anypage') }}</h5>{!! getAd('show_page_ad_1') !!} 
	<h5>{{ trans('ads.anypage') }}</h5>{!! getAd('show_page_ad_2') !!} 
	
 </div> </div></aside> 
@endsection</div>