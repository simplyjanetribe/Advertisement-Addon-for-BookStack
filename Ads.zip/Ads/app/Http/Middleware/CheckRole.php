<?php namespace BookStack\Http\Middleware;

use Closure;
use Illuminate\Support\Facades\Auth;
use Illuminate\Support\Facades\DB;

class CheckRole
{
    /**
     * Handle an incoming request.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  \Closure  $next
     * @param  string  $roleId
     * @return mixed
     */
    public function handle($request, Closure $next, $roleId)
    {
        $user = Auth::user();
        if ($user) {
            $userRole = DB::table('role_user')->where('user_id', $user->id)->first();
            \Log::info('User ID: ' . $user->id . ' Role ID: ' . $userRole->role_id);

            if ($userRole && $userRole->role_id == $roleId) {
                return $next($request);
            }
        } else {
            \Log::info('No authenticated user');
        }

        return redirect()->back()->with('error', 'Unauthorized');
    }
}



       