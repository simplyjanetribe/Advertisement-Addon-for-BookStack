<?php


if (!function_exists('getAd')) {
    function getAd($position) {
        $ads = \BookStack\Entities\Models\Ads::first();
        $cspNonce = app(\BookStack\Util\CspService::class)->getNonce();
        return isset($ads->$position) ? str_replace('%%NONCE%%', $cspNonce, $ads->$position) : '';
    }
}