<?php namespace BookStack\Ads\Controllers;

use Illuminate\Http\Request;
use BookStack\Http\Controller;
use Illuminate\Support\Facades\Auth;
use Illuminate\Support\Facades\Log;
use Illuminate\Support\Str;
use BookStack\Ads\Models\Ads;

use BookStack\Ads\Helpers\AdHelper;
use BookStack\Users\Models\User;
use BookStack\Users\UserRepo;

class AdsController extends Controller{
	
	public function createAds()
    {
		
        $ads = Ads::first(); // Assuming there will be only one set of ads
        return view('ads.ads', compact('ads'));
    }
public function script()
{
    $nonce = csrf_token(); // or however you're generating the nonce
    return view('ads.ads', compact('nonce'));
}
    public function storeAds(Request $request)
    {
		
		
        $request->validate([
            'header_ad' => 'nullable|string',
            'footer_ad' => 'nullable|string',
            'sidebar_ad' => 'nullable|string',
            'show_page_ad_1' => 'nullable|string',
            'show_page_ad_2' => 'nullable|string',
        ]);

        $ads = Ads::firstOrNew();
		
        $ads->header_ad = $request->header_ad;
        $ads->footer_ad = $request->footer_ad;
        $ads->sidebar_ad = $request->sidebar_ad;
        $ads->show_page_ad_1 = $request->show_page_ad_1;
        $ads->show_page_ad_2 = $request->show_page_ad_2;
        $ads->save();

        return redirect()->route('ads.ads')->with('success', 'Ads updated successfully.');
    




 
        return view('ads.ads');

    }}
	
	