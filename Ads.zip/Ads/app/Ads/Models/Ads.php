<?php namespace BookStack\Ads\Models;

use Illuminate\Database\Eloquent\Model;

class Ads extends Model
{
    protected $fillable = [
        'header_ad',
        'footer_ad',
        'sidebar_ad',
        'show_page_ad_1',
        'show_page_ad_2'
    ];
}