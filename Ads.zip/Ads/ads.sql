-- phpMyAdmin SQL Dump
-- version 5.2.1
-- https://www.phpmyadmin.net/
--
-- Host: localhost:3306
-- Generation Time: Jul 27, 2024 at 05:49 PM
-- Server version: 8.0.37-0ubuntu0.24.04.1
-- PHP Version: 8.3.8

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `bookstacks`
--

-- --------------------------------------------------------

--
-- Table structure for table `ads`
--

CREATE TABLE `ads` (
  `id` int UNSIGNED NOT NULL,
  `header_ad` text COLLATE utf8mb4_unicode_ci,
  `footer_ad` text COLLATE utf8mb4_unicode_ci,
  `sidebar_ad` text COLLATE utf8mb4_unicode_ci,
  `show_page_ad_1` text COLLATE utf8mb4_unicode_ci,
  `show_page_ad_2` text COLLATE utf8mb4_unicode_ci,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `ads`
--

INSERT INTO `ads` (`id`, `header_ad`, `footer_ad`, `sidebar_ad`, `show_page_ad_1`, `show_page_ad_2`, `created_at`, `updated_at`) VALUES
(1, '<img src=\"https://qph.cf2.quoracdn.net/main-qimg-06e7f4b130a4549d975f40a61f770228-lq\" alt=\"Girl in a jacket\" width=\"100%\">', '<center><script src=\"https://www.astrolookup.com/js/widget/ascendant-script.js\"></script></center>', '<img src=\"https://qph.cf2.quoracdn.net/main-qimg-06e7f4b130a4549d975f40a61f770228-lq\" alt=\"Girl in a jacket\" width=\"100%\">', '<img src=\"https://cdn.vectorstock.com/i/500p/91/09/place-your-ad-here-advertisement-banners-all-size-vector-27099109.jpg\" alt=\"\" width=\"100%\">', '<iframe width=\"560\" height=\"315\" src=\"https://www.youtube.com/embed/ktlwozOcMaA?si=gsjH5TuhejT7K9iE\" title=\"YouTube video player\" frameborder=\"0\" allow=\"accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture; web-share\" referrerpolicy=\"strict-origin-when-cross-origin\" allowfullscreen></iframe>', '2024-07-26 01:52:31', '2024-07-27 17:27:51');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `ads`
--
ALTER TABLE `ads`
  ADD PRIMARY KEY (`id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `ads`
--
ALTER TABLE `ads`
  MODIFY `id` int UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
